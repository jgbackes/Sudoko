/**
 * User: jbackes
 * Date: Dec 20, 2006
 * Time: 5:46:06 PM
 * Copyright (c) SenSage, Inc.
 */
public interface Solution {

    public void solver(int[][] newValues);

    public void reset();

    public int getVisits(int row, int col);

    class RowCol {
        public int row;
        public int col;

        public RowCol(int row, int col) {
            this.row = row;
            this.col = col;
        }
    }
}
