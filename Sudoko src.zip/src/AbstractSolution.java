/**
 * User: jbackes
 * Date: Nov 20, 2008
 * Time: 7:24:35 PM
 * Copyright 2007, Jeffrey G. Backes. All rights reserved.
 */
public abstract class AbstractSolution implements Solution {
    protected int[][] values = new int[9][9];
    protected int[][] visits = new int[9][9];

    public SudokuFrame sudokuFrame;
}
