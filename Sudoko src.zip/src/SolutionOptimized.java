import javax.swing.*;

/**
 * User: jbackes
 * Date: Dec 20, 2006
 * Time: 5:46:06 PM
 * Copyright (c) SenSage, Inc.
 */
public class SolutionOptimized extends AbstractSolution {

    // Row Column Value array, true if at [x][y] value z is legal
    private boolean[][][] available = new boolean[9][9][9];

    public static void main(String[] args) {
        AbstractSolution app = new SolutionOptimized();
        app.sudokuFrame = new SudokuFrame(app);
        app.sudokuFrame.setVisible(true);
        app.sudokuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        app.sudokuFrame.setUserInput(CannedPuzzles.getRandomPuzzle().getValues(), false);
    }

    public void solver(int[][] newValues) {
        sudokuFrame.setTime(-1);
        load(newValues);
        long time = System.nanoTime();

        for (int r = 0; r < 10; r++) {
            for (int c = 0; c < 10; c++) {
                if (values[r][c] == 0) {
                    for (int v = 0; v < 10; v++) {
                        available[r][c][v] = isEmpty(r, c, v);
                    }
                }
            }
        }
        // Here is where the work gets done, start the recursive solution
        tryOne(0, 0);

        final double endtime = ((double) (System.nanoTime() - time)) / ((double) (1000 * 1000));

        // Now that we have the results, display them on the swing thread
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (sudokuFrame.shouldShowProgress()) {
                    sudokuFrame.setUserInput(values, false);
                }

                sudokuFrame.setTime(endtime);
                sudokuFrame.setUserInput(values, true);
                sudokuFrame.setAllDone();
            }
        });
    }

    public void reset() {
        visits = new int[9][9];
        sudokuFrame.setUserInput(CannedPuzzles.getRandomPuzzle().getValues(), false);
    }

    public RowCol nextRowCol(int row, int col) {
        col++;
        if (col > 8) {
            col = 0;
            row++;
        }

        return new RowCol(row, col);
    }

    public RowCol nextZero(int row, int col) {
        RowCol result = null;

        while (row < 9 && col < 9 && result == null) {
            if (values[row][col] == 0) {
                result = new RowCol(row, col);
            } else {
                RowCol next = nextRowCol(row, col);
                row = next.row;
                col = next.col;
            }
        }

        return result;
    }

    private void showProgress(final int row, final int col, final int value) {
        try {
            if (sudokuFrame.shouldShowProgress()) {
                SwingUtilities.invokeAndWait(new Runnable() {
                    public void run() {
                        sudokuFrame.setUserInputRowColumn(row, col, value);
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean tryOne(final int inRow, final int inCol) {
        boolean result = false;

        RowCol nextBlank = nextZero(inRow, inCol);

        if (null != nextBlank) {
            final int xrow = nextBlank.row;
            final int xcol = nextBlank.col;

            for (int guess = 1; guess < 10; guess++) {
                if (isEmpty(xrow, xcol, guess)) {
                    values[xrow][xcol] = guess;
                    visits[xrow][xcol]++;
                    showProgress(xrow, xcol, guess);
                    RowCol next = nextRowCol(xrow, xcol);

                    if (tryOne(next.row, next.col)) {
                        result = true;
                        break;
                    }
                }
            }
            // We did not find a number that worked, clear up our guess and cause backtracking
            if (!result) {
                values[xrow][xcol] = 0;
                showProgress(xrow, xcol, 0);
            }
        } else {
            result = true; // all done, simply unwind the recursion
        }
        return result;
    }

    private void load(int[][] values) {
        for (int i = 0; i < 9; i++) {
            System.arraycopy(values[i], 0, this.values[i], 0, 9);
        }
        visits = new int[9][9];
    }

    private boolean isEmpty(int row, int col, int value) {
        return !rowHas(row, value) && !columnHas(col, value) && !blockHas(row, col, value);
    }

    private boolean rowHas(int row, int value) {
        return values[row][0] == value ||
                values[row][1] == value ||
                values[row][2] == value ||
                values[row][3] == value ||
                values[row][4] == value ||
                values[row][5] == value ||
                values[row][6] == value ||
                values[row][7] == value ||
                values[row][8] == value;
    }

    private boolean columnHas(int col, int value) {

        return values[0][col] == value ||
                values[1][col] == value ||
                values[2][col] == value ||
                values[3][col] == value ||
                values[4][col] == value ||
                values[5][col] == value ||
                values[6][col] == value ||
                values[7][col] == value ||
                values[8][col] == value;
    }

    private boolean blockHas(int row, int col, int value) {
        row -= (row % 3);
        col -= (col % 3);
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (values[r + row][c + col] == value) {
                    return true;
                }
            }
        }
        return false;
    }

    public int getVisits(int row, int col) {
        return visits[row][col];
    }

    /**
     * Class to store two ints
     */
    class RowCol {
        public int row;
        public int col;

        public RowCol(int row, int col) {
            this.row = row;
            this.col = col;
        }
    }
}
