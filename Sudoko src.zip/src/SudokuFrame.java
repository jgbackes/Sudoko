// Copyright (c) 2006 SenSage, Inc.  All rights reserved.

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

/**
 *
 */
public class SudokuFrame extends JFrame {
    private JTextField[][] textfields;

    private Solution app;
    private JLabel timeLabel = new JLabel("Total time:");
    final JCheckBox showProgress = new JCheckBox("Show Progress");
    final JButton startButt = new JButton("Start");
    final JButton quitButt = new JButton("Reset");

    public SudokuFrame(Solution app) {
        this.app = app;
        initUI();
    }

    private void initUI() {
        setTitle("Solution Solver");

        final JPanel jp = new JPanel(new FlowLayout(FlowLayout.LEFT));
        jp.add(new JLabel("Total time:"));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        final JPanel panel = new JPanel(new GridLayout(3, 3, 0, 0));
        panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        textfields = new DigitField[9][9];
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                final JPanel section = new JPanel(new GridLayout(3, 3, 2, 2));
                section.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
                panel.add(section);
                for (int i = row * 3; i < (row * 3) + 3; i++) {
                    for (int j = col * 3; j < (col * 3) + 3; j++) {
                        textfields[i][j] = new DigitField(2);
                        textfields[i][j].setHorizontalAlignment(JTextField.CENTER);
                        section.add(textfields[i][j]);
                    }
                }
            }
        }

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panel, BorderLayout.CENTER);

        final JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        // by default show progress
        showProgress.setSelected(true);

        startButt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startButt.setEnabled(false);
                quitButt.setEnabled(false);
                new Thread(new Runnable() {
                    public void run() {
                        app.solver(getUserInput());
                    }
                }).start();
            }
        });

        quitButt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread(new Runnable() {
                    public void run() {
                        resetUserInput();
                        app.reset();
                    }
                }).start();
            }
        });

        buttonPanel.add(showProgress);
        buttonPanel.add(startButt);
        buttonPanel.add(quitButt);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        final JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        timePanel.add(timeLabel);
        getContentPane().add(timePanel, BorderLayout.NORTH);

        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public boolean shouldShowProgress() {
        return showProgress.isSelected();
    }

    public void setAllDone() {
        startButt.setEnabled(true);
        quitButt.setEnabled(true);
    }

    public void setTime(final double time) {
        if (time == -1) {
            timeLabel.setText("Total time: working...");
        } else {
            timeLabel.setText("Total time: " + time + " ms");
        }
    }

    public void setUserInputRowColumn(int row, int col, int value) {
        Color backColor = Color.WHITE;

        if (value == 0) {
            textfields[row][col].setForeground(Color.RED);
            int visits = app.getVisits(row, col);
            if (visits == 0) {
                backColor = Color.WHITE;
            } else if (visits < 100) {
                backColor = Color.LIGHT_GRAY;
            } else if (visits < 1000) {
                backColor = Color.GRAY;
            } else if (visits < 5000) {
                backColor = Color.DARK_GRAY;
            } else {
                backColor = Color.BLACK;
            }
        }

        textfields[row][col].setBackground(backColor);
        textfields[row][col].setText("" + value);
    }

    public void setUserInput(int[][] values, boolean running) {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                setUserInputRowColumn(row, col, values[row][col]);
            }
        }
    }

    public void resetUserInput() {
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                textfields[row][col].setForeground(Color.BLACK);
            }
        }
    }

    public int[][] getUserInput() {

        final int[][] values = new int[9][9];
        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                if (textfields[row][col].getText().length() == 0) {
                    values[row][col] = 0;
                } else {
                    values[row][col] = Integer.parseInt(textfields[row][col].getText());
                }
            }
        }
        return values;
    }

    private class DigitField extends JTextField {

        public DigitField(int cols) {
            super(cols);
        }

        protected Document createDefaultModel() {
            return new DigitDocument();
        }

        private class DigitDocument extends PlainDocument {
            public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {

                if (offs > 0) {
                    Toolkit.getDefaultToolkit().beep();
                    return;
                }
                if (str == null) {
                    return;
                }
                try {
                    Integer.parseInt(str);
                }
                catch (NumberFormatException e) {
                    Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.insertString(offs, str, a);

            }
        }
    }
}
