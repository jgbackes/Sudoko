/**
 * User: jbackes
 * Date: Dec 21, 2006
 * Time: 11:17:52 AM
 * Copyright (c) SenSage, Inc.
 */
public class Puzzle {
    public final static int EASY = 1;
    public final static int MEDIUM = 2;
    public final static int HARD = 3;
    public final static int VERY_HARD = 4;

    String name;
    int difficulty;
    int[][] values;

    public Puzzle(String name, int difficulty, int[][] values) {
        this.name = name;
        this.difficulty = difficulty;
        this.values = values;
    }

    public String getName() {
        return name;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public int[][] getValues() {
        return values;
    }
}
